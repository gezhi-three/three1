create trigger generate_create_time
  before INSERT
  on article
  for each row
  BEGIN
 SET  new.create_date = NOW();
END;

